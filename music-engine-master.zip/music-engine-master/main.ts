for (let index = 0; index < 100; index++) {
    music.playMelody("E B C5 A B G A F ", 100)
}
